export default /*html*/`
<tr>
    <td class="font-weight-bold color-rol" colspan="5" ><strong> MENSAJERIA </strong></td>
</tr>
<tr data-menu="mensajeria-chat">
    <td>Chat</td>
    <td class="text-center"><input type="checkbox" name="view" class="i-checks"></td>
</tr>


`;