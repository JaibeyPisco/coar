export default `
<tr>
    <td class="font-weight-bold color-rol" colspan="5" ><strong> TESORERIA
        </strong></td>
</tr>

<tr data-menu="tesoreria-caja_chica">
    <td>Caja chica</td>
    <td class="text-center"><input type="checkbox" name="view"></td>
    <td class="text-center"><input type="checkbox" name="new"></td>
    <td class="text-center"><input type="checkbox" name="edit"></td>
    <td class="text-center"><input type="checkbox" name="delete"></td>
</tr>

<tr data-menu="tesoreria-reporte_caja_chica">
    <td>Reporte Caja chica</td>
    <td class="text-center"><input type="checkbox" name="view"></td>
    <td class="text-center"><input type="checkbox" name="new"></td>
    <td class="text-center"><input type="checkbox" name="edit"></td>
    <td class="text-center"><input type="checkbox" name="delete"></td>
</tr>

<tr data-menu="tesoreria-reporte_consolidado_caja">
    <td>Consolidado Caja</td>
    <td class="text-center"><input type="checkbox" name="view"></td>
    <td class="text-center"><input type="checkbox" name="new"></td>
    <td class="text-center"><input type="checkbox" name="edit"></td>
    <td class="text-center"><input type="checkbox" name="delete"></td>
</tr>

`;