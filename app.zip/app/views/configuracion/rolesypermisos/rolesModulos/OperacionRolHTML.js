export default /*html*/`

    <tr>
        <td class="font-weight-bold color-rol" colspan="5" ><strong> OPERACIÓN
            </strong></td>
    </tr>

    <tr data-menu="operacion-nueva_incidencia">
        <td>Nueva Incidencia</td>
        <td class="text-center"><input type="checkbox" name="view"></td>
        <td class="text-center"><input type="checkbox" name="new"></td>
        <td class="text-center"><input type="checkbox" name="edit"></td>
        <td class="text-center"><input type="checkbox" name="delete"></td>
    </tr>

    <tr data-menu="operacion-incidencias">
        <td>Incidencias</td>
        <td class="text-center"><input type="checkbox" name="view"></td>
        <td class="text-center"><input type="checkbox" name="new"></td>
        <td class="text-center"><input type="checkbox" name="edit"></td>
        <td class="text-center"><input type="checkbox" name="delete"></td>
    </tr>
    <tr data-menu="operacion-derivacion">
        <td>Derivaciones</td>
        <td class="text-center"><input type="checkbox" name="view"></td>
        <!-- <td class="text-center"><input type="checkbox" name="new"></td> -->
        <td class="text-center"><input type="checkbox" name="edit"></td>
        <!-- <td class="text-center"><input type="checkbox" name="delete"></td> -->
    </tr>
`;