export default `

<tr>
    <td class="font-weight-bold color-rol" colspan="5" ><strong> ALMACÉN
        </strong></td>
</tr>

<tr data-menu="almacen-equipo">
    <td>Equipo</td>
    <td class="text-center"><input type="checkbox" name="view"></td>
    <td class="text-center"><input type="checkbox" name="new"></td>
    <td class="text-center"><input type="checkbox" name="edit"></td>
    <td class="text-center"><input type="checkbox" name="delete"></td>
</tr>

<tr data-menu="almacen-compra_equipo">
    <td>Compra Equipo</td>
    <td class="text-center"><input type="checkbox" name="view"></td>
    <td class="text-center"><input type="checkbox" name="new"></td>
    <td class="text-center"><input type="checkbox" name="edit"></td>
    <td class="text-center"><input type="checkbox" name="delete"></td>
</tr>
`;