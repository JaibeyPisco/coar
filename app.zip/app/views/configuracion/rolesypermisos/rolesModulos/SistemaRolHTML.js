export default /*html*/`
<tr>
    <td class="font-weight-bold color-rol" colspan="5" ><strong> SISTEMA
        </strong></td>
</tr>


<tr data-menu="sistema-categoria">
    <td>Categoria</td>
    <td class="text-center"><input type="checkbox" name="view"></td>
    <td class="text-center"><input type="checkbox" name="new"></td>
    <td class="text-center"><input type="checkbox" name="edit"></td>
    <td class="text-center"><input type="checkbox" name="delete"></td>
</tr>

<tr data-menu="sistema-unidad_medida">
    <td>Unidad Medida</td>
    <td class="text-center"><input type="checkbox" name="view"></td>
    <td class="text-center"><input type="checkbox" name="new"></td>
    <td class="text-center"><input type="checkbox" name="edit"></td>
    <td class="text-center"><input type="checkbox" name="delete"></td>
</tr>

<tr data-menu="sistema-proveedor">
    <td>Proveedor</td>
    <td class="text-center"><input type="checkbox" name="view"></td>
    <td class="text-center"><input type="checkbox" name="new"></td>
    <td class="text-center"><input type="checkbox" name="edit"></td>
    <td class="text-center"><input type="checkbox" name="delete"></td>
</tr>

<tr data-menu="sistema-producto">
    <td>Producto</td>
    <td class="text-center"><input type="checkbox" name="view"></td>
    <td class="text-center"><input type="checkbox" name="new"></td>
    <td class="text-center"><input type="checkbox" name="edit"></td>
    <td class="text-center"><input type="checkbox" name="delete"></td>
</tr>

<tr data-menu="sistema-cliente">
    <td>Cliente</td>
    <td class="text-center"><input type="checkbox" name="view"></td>
    <td class="text-center"><input type="checkbox" name="new"></td>
    <td class="text-center"><input type="checkbox" name="edit"></td>
    <td class="text-center"><input type="checkbox" name="delete"></td>
</tr>
<tr data-menu="sistema-docente">
    <td>Docente</td>
    <td class="text-center"><input type="checkbox" name="view"></td>
    <td class="text-center"><input type="checkbox" name="new"></td>
    <td class="text-center"><input type="checkbox" name="edit"></td>
    <td class="text-center"><input type="checkbox" name="delete"></td>
</tr>
<tr data-menu="sistema-curso">
    <td>Curso</td>
    <td class="text-center"><input type="checkbox" name="view"></td>
    <td class="text-center"><input type="checkbox" name="new"></td>
    <td class="text-center"><input type="checkbox" name="edit"></td>
    <td class="text-center"><input type="checkbox" name="delete"></td>
</tr>
<tr data-menu="sistema-horario">
    <td>Horario</td>
    <td class="text-center"><input type="checkbox" name="view"></td>
    <td class="text-center"><input type="checkbox" name="new"></td>
    <td class="text-center"><input type="checkbox" name="edit"></td>
    <td class="text-center"><input type="checkbox" name="delete"></td>
</tr>
<tr data-menu="sistema-planificacion_laboratorios">
    <td>Planificación de Laboratorios</td>
    <td class="text-center"><input type="checkbox" name="view"></td>
    <td class="text-center"><input type="checkbox" name="new"></td>
    <td class="text-center"><input type="checkbox" name="edit"></td>
    <td class="text-center"><input type="checkbox" name="delete"></td>
</tr>
<tr data-menu="sistema-compra">
    <td>Compra</td>
    <td class="text-center"><input type="checkbox" name="view"></td>
    <td class="text-center"><input type="checkbox" name="new"></td>
    <td class="text-center"><input type="checkbox" name="edit"></td>
    <td class="text-center"><input type="checkbox" name="delete"></td>
</tr>
<tr data-menu="sistema-incidencia">
    <td>Incidencia</td>
    <td class="text-center"><input type="checkbox" name="view"></td>
    <td class="text-center"><input type="checkbox" name="new"></td>
    <td class="text-center"><input type="checkbox" name="edit"></td>
    <td class="text-center"><input type="checkbox" name="delete"></td>
</tr>
<tr data-menu="sistema-entradasalidaproducto">
    <td>Entrada y Salida Productos</td>
    <td class="text-center"><input type="checkbox" name="view"></td>
    <td class="text-center"><input type="checkbox" name="new"></td>
    <td class="text-center"><input type="checkbox" name="edit"></td>
    <td class="text-center"><input type="checkbox" name="delete"></td>
</tr>


`;