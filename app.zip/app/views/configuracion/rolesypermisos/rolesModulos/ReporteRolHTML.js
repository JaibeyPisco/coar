export default /*html*/`
 
 
 <tr>
    <td class="font-weight-bold color-rol" colspan="5"  ><strong> REPORTES </strong></td>
</tr>
<tr data-menu="reporte-movimiento_informacion">
    <td>Movimiento de Información</td>
    <td class="text-center"><input type="checkbox" name="view" class="i-checks"></td>
</tr>
<tr data-menu="reporte-incidencias">
    <td>Incidencias</td>
    <td class="text-center"><input type="checkbox" name="view" class="i-checks"></td>
</tr>

`;