export default /*html*/`
  <tr>
        <td class="font-weight-bold color-rol" colspan="5"  ><strong> DASHBOARD </strong></td>
    </tr>
    <tr data-menu="dashboard-general">
        <td>Sistema General</td>
        <td class="text-center"><input type="checkbox" name="view"></td>
        <td class="text-center"></td>
        <td class="text-center"></td>
        <td class="text-center"></td>
    </tr>


`;