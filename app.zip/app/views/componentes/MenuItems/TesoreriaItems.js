export default  /*html*/`
    <li name="modulo" id="sidebar-tesoreria">
      <a href="javascript:;" class="has-arrow">
        <div class="parent-icon"><i class="fadeIn animated bx bx-money"></i></div>
        <div class="menu-title">Tesoreria</div>
      </a>
      <ul>
        <li id="sidebar-tesoreria-caja_chica">
          <a href="#/tesoreria/caja_chica">
            <i class="bx bx-right-arrow-alt"></i>Caja chica
          </a>
        </li>
        <li id="sidebar-tesoreria-reporte_caja_chica">
          <a href="#/tesoreria/reporte_caja_chica">
            <i class="bx bx-right-arrow-alt"></i>Reporte Caja chica
          </a>
        </li>

        <li id="sidebar-tesoreria-reporte_consolidado_caja">
          <a href="#/tesoreria/reporte_consolidado_caja">
            <i class="bx bx-right-arrow-alt"></i>Consolidado Caja
          </a>
        </li>
 
      </ul>
    </li>  
    `